package personajes;

public interface Arma {
    void mostrar();
}
