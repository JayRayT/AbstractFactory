package personajes;

public class ArmaElfo implements Arma {
    @Override
    public void mostrar() {
        System.out.println("Arco largo mágico de Elfo.");
    }
}
