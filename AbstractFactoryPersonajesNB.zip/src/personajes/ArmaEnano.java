package personajes;

public class ArmaEnano implements Arma {
    @Override
    public void mostrar() {
        System.out.println("Martillo de guerra Enano.");
    }
}
