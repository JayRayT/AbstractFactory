package personajes;

public class ArmaHumano implements Arma {
    @Override
    public void mostrar() {
        System.out.println("Espada templada de Humano.");
    }
}
