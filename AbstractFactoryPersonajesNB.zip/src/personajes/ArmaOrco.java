package personajes;

public class ArmaOrco implements Arma {
    @Override
    public void mostrar() {
        System.out.println("Gran hacha de guerra Orco.");
    }
}
