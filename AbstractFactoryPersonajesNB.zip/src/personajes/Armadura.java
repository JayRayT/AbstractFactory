package personajes;

public interface Armadura {
    void mostrar();
}
