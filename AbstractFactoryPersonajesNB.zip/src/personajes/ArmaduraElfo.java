package personajes;

public class ArmaduraElfo implements Armadura {
    @Override
    public void mostrar() {
        System.out.println("Armadura ligera y élfica.");
    }
}
