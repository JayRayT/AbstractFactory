package personajes;

public class ArmaduraEnano implements Armadura {
    @Override
    public void mostrar() {
        System.out.println("Armadura resistente y pesada de Enano.");
    }
}
