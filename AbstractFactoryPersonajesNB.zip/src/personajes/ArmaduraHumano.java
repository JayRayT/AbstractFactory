package personajes;

public class ArmaduraHumano implements Armadura {
    @Override
    public void mostrar() {
        System.out.println("Armadura de acero refinada de Humano.");
    }
}
