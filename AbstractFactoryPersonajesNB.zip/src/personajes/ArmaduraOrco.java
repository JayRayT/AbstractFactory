package personajes;

public class ArmaduraOrco implements Armadura {
    @Override
    public void mostrar() {
        System.out.println("Armadura pesada y tosca de Orco.");
    }
}
