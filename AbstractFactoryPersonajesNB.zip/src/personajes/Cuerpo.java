package personajes;

public interface Cuerpo {
    void mostrar();
}
