package personajes;

public class CuerpoElfo implements Cuerpo {
    @Override
    public void mostrar() {
        System.out.println("Cuerpo esbelto y elegante de Elfo.");
    }
}
