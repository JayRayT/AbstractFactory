package personajes;

public class CuerpoEnano implements Cuerpo {
    @Override
    public void mostrar() {
        System.out.println("Cuerpo bajo y fornido de Enano.");
    }
}
