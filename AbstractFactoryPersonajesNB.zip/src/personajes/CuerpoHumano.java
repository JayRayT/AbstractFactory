package personajes;

public class CuerpoHumano implements Cuerpo {
    @Override
    public void mostrar() {
        System.out.println("Cuerpo ágil y adaptable de Humano.");
    }
}
