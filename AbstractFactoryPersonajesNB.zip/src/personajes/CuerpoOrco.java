package personajes;

public class CuerpoOrco implements Cuerpo {
    @Override
    public void mostrar() {
        System.out.println("Cuerpo robusto y verde de Orco.");
    }
}
