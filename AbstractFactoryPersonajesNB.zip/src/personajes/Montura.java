package personajes;

public interface Montura {
    void mostrar();
}
