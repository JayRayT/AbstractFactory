package personajes;

public class MonturaElfo implements Montura {
    @Override
    public void mostrar() {
        System.out.println("Ciervo místico como montura de Elfo.");
    }
}
