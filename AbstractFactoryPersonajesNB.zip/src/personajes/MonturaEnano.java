package personajes;

public class MonturaEnano implements Montura {
    @Override
    public void mostrar() {
        System.out.println("Jabalí como montura de Enano.");
    }
}
