package personajes;

public class MonturaHumano implements Montura {
    @Override
    public void mostrar() {
        System.out.println("Caballo noble como montura de Humano.");
    }
}
