package personajes;

public class MonturaOrco implements Montura {
    @Override
    public void mostrar() {
        System.out.println("Lobo gigante como montura de Orco.");
    }
}
